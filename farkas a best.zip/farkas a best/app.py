from flask import Flask, render_template
import os
 
app = Flask(__name__)
 
img = os.path.join('static', 'Image')
 
@app.route('/')
def home():
    file = os.path.join(img, 'GP.png')
    return render_template('feltöltés.html', image=file)
 
if __name__ == '__main__':
    app.run(debug=True)
    
from flask import Flask, render_template, request
from werkzeug.utils import secure_filename
import os
 
app = Flask(__name__)
 
upload_folder = os.path.join('static', 'uploads')
 
app.config['UPLOAD'] = upload_folder
 
@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        file = request.files['img']
        filename = secure_filename(file.filename)
        file.save(os.path.join(app.config['UPLOAD'], filename))
        img = os.path.join(app.config['UPLOAD'], filename)
        return render_template('feltöltés.html', img=img)
    return render_template('feltöltés.html')
 
 
if __name__ == '__main__':
    app.run(debug=True, port=8001)